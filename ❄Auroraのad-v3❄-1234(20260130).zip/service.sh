#!/system/bin/sh
#
MODDIR=${0%/*}
SCRIPT_DIR="/data/adb/agh/scripts"
AGH_DIR="/data/adb/agh"
CONFIG_FILE="$MODDIR/admin/配置文件.md"


until [ "$(getprop sys.boot_completed)" = "1" ]; do
sleep 2
done


#❄️海边会下雪么❄️给权限
chmod -R 777 "$AGH_DIR"* >/dev/null 2>&1
chmod -R 777 "$MODDIR/admin/"* >/dev/null 2>&1
chmod -R 777 "$MODDIR/bin/"* >/dev/null 2>&1
chmod -R 777 "$MODDIR/cron"*
chmod  777 "$MODDIR/action.sh"
chmod  777 "$MODDIR/service3.sh"
chmod  777 "$MODDIR/action2.sh"
handle_config() {
    local config_file="$1" prop_name="$2" script_path="$3"
    local first_line=$(head -n1 "$config_file" 2>/dev/null)
    
    case "$first_line" in
        *on*)
            sed -i "s/${prop_name}:[a-z]*/${prop_name}:on/" /data/adb/modules/Aurora/module.prop

            setsid "$script_path" >/dev/null 2>&1 &
            ;;
        *off*)
         
            sed -i "s/${prop_name}:[a-z]*/${prop_name}:off/" /data/adb/modules/Aurora/module.prop
            ;;
    esac
}
handle_config2() {
    local config_file="$1" prop_name="$2" script_path="$3"
    local first_line=$(head -n1 "$config_file" 2>/dev/null)
    
    case "$first_line" in
        *on*)
            sed -i "s/${prop_name}:[a-z]*/${prop_name}:on/" /data/adb/modules/Aurora/module.prop
            ;;
        *off*)
            sed -i "s/${prop_name}:[a-z]*/${prop_name}:off/" /data/adb/modules/Aurora/module.prop
            ;;
    esac
}

#handle_config "$MODDIR/admin/进程压制.md" "进程压制" "$MODDIR/bin/Prevent/process"
handle_config "$MODDIR/admin/广告拦截.md" "广告拦截" "$MODDIR/bin/update.sh"

handle_config2 "$MODDIR/admin/内存压制.md" "内存压制" "$MODDIR/bin/Prevent/neicunyazhi"

handle_config2 "$MODDIR/admin/MounterMover.md" "重定向" "$MODDIR/bin/Tiaoyou/xitongtiaoyou"
setsid "$MODDIR/bin/Prevent/neicunyazhi" >/dev/null 2>&1 &

$MODDIR/service3.sh >/dev/null 2>&1
