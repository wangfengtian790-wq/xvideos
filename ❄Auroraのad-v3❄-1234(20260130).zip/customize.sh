#!/sbin/sh
#别看了这里啥也没有

MODDIR=${0%/*}
Admin_FILE="$MODPATH/admin/配置文件.md"

chooseport() {
getevent -qlc 1 >/dev/null 2>&1
    while true; do
        # 捕获按键事件并过滤出按下动作
        local key_event=$(getevent -qlc 1 2>/dev/null | 
            awk '/KEY_VOLUMEUP/ {print "KEY_VOLUMEUP"; exit} 
                 /KEY_VOLUMEDOWN/ {print "KEY_VOLUMEDOWN"; exit}')
        [[ -n "$key_event" ]] && break
    done
    [[ "$key_event" == "KEY_VOLUMEUP" ]] && return 0 || return 1
}
key_source(){
if test -e "$1" ;then
	source "$1"
	rm -rf "$1"
fi
}

ext(){
key_source $MODPATH/tiaoyou.sh
test -d $MODPATH/busybox && {
set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}
}
show_prompt() {
    ui_print "║  $1 ║"
    ui_print "║                                      ║"
    ui_print "║  音量上键: 要 ✅                  ║"
    ui_print "║  音量下键: 不要❌                  ║"
    ui_print "╚══════════════════════════════════════╝"
    ui_print " "
    chooseport
    return $?
}





function inherit_admin2() {
    ui_print " "
    ui_print "╔══════════════════════════════════════╗"
    ui_print "║          配置文件继承                ║"
    ui_print "╚══════════════════════════════════════╝"
    
# 读取当前模块版本号
current=$(grep '^versionCode=' "/data/adb/modules/Aurora/module.prop" 2>/dev/null | cut -d= -f2)
current2=$(grep '^versionCode=' "$MODPATH/module.prop" 2>/dev/null | cut -d= -f2)
# 判断是否应该继承配置小于3
if [ -d "/data/adb/modules/Aurora" ] && [ $((current2 - current)) -lt 10 ]; then
if [ -f "/data/adb/modules/Aurora/admin/gglj" ]; then

        rm -f "$UPDATE_SCRIPT" 2>/dev/null
       rm -rf "$MODPATH/bin/agh" 2>/dev/null
    fi
    ui_print "🔄 正在继承配置文件..."
    ui_print " "
ui_print " "
ui_print " "
ui_print " "
#cp -f  "$MODPATH/admin/进程压制.md" "/data/adb/modules/Aurora/admin"  2>/dev/null
#cp -f "$MODPATH/admin/文件归类.md" "/data/adb/modules/Aurora/admin"   2>/dev/null
#cp -f "$MODPATH/admin/Dex2oat.md" "/data/adb/modules/Aurora/admin"   2>/dev/null
cp -f "$MODPATH/admin/扫描清理.md" "/data/adb/modules/Aurora/admin"   2>/dev/null
#cp -f "$MODPATH/admin/MounterMover.md" "/data/adb/modules/Aurora/admin/MounterMover.md" 2>/dev/null
sleep 1
    cp -rf "/data/adb/modules/Aurora/admin/"* "$MODPATH/admin/" 2>/dev/null
  # guanggaolanjie
    cp -f "/data/adb/modules/Aurora/stats" "$MODPATH" 2>/dev/null
    
    ui_print "✅ 配置文件继承完成"
    ui_print "✅ 配置文件继承完成"
else

    ui_print "❌ 检验到版本号差异过大"
    ui_print "📝 将使用全新配置进行安装"
    ui_print " "
ui_print " "
ui_print " "
ui_print " "
    guanggaolanjie
    neicunyazhi
    xitongtiaoyou
fi

}
guanggaolanjie(){
ui_print "❄️⭕是否开启广告拦截？⭕❄️"
ui_print "⚠️注意：可能与其他去广告模块冲突⚠️"

SERVICE_FILE="$MODPATH/service.sh"
UPDATE_SCRIPT="$MODPATH/bin/update.sh"
AGH_DIR="/data/adb/modules/Aurora/bin/agh"
BACKUP_DIR="/data/adb/modules/Aurora/bin/agh/agh_backup_temp"
CONFIG_FILE="$MODPATH/admin/广告拦截.md"
if show_prompt "❄️是否开启广告拦截功能？❄️"; then
    echo "on" > "$CONFIG_FILE"
    
    # 备份配置（在删除前）
    if [ -d "$AGH_DIR" ]; then
        mkdir -p "$BACKUP_DIR"
        cp -f "$AGH_DIR"/bin/AdGuardHome.yaml "$BACKUP_DIR"/ 2>/dev/null
        cp -f "$AGH_DIR"/scripts/*.sh "$BACKUP_DIR"/ 2>/dev/null
    fi
    
    # 删除旧目录并移动新目录
if [ ! -d "/data/adb/modules/AdGuardHome" ]; then
   rm -rf "/data/adb/agh" 2>/dev/null

fi
    
    # 恢复配置（在移动后）
    if [ -d "$BACKUP_DIR" ]; then

        cp -f "$BACKUP_DIR"/AdGuardHome.yaml "/data/adb/modules/Aurora/bin/agh/bin/" 2>/dev/null
        cp -f "$BACKUP_DIR"/*.sh "/data/adb/modules/Aurora/bin/agh/scripts/" 2>/dev/null
        rm -rf "$BACKUP_DIR" 2>/dev/null
    fi
    rm -f  "$MODPATH/admin/gglj" 2>/dev/null
    ui_print "✅ 广告拦截已开启"
else
    if show_prompt "❄️永久关闭(上)还是暂时关闭(下)？❄️"; then
        # 永久关闭      
        rm -f "$UPDATE_SCRIPT" 2>/dev/null
        rm -rf "$MODPATH/bin/agh" 2>/dev/null
       [ ! -d "/data/adb/modules/AdGuardHome" ] && rm -rf "/data/adb/agh" 2>/dev/null
        echo "off" > "$CONFIG_FILE"
        sed -i "s/广告拦截:[a-z]*/广告拦截:off/" /data/adb/modules/Aurora/module.prop 2>/dev/null
        touch "$MODPATH/admin/gglj" 2>/dev/null
    else
        # 暂时关闭
        echo "off" > "$CONFIG_FILE"
        sed -i "s/广告拦截:[a-z]*/广告拦截:off/" /data/adb/modules/Aurora/module.prop 2>/dev/null
        rm -f  "$MODPATH/admin/gglj" 2>/dev/null
        ui_print "⏸️ 广告拦截已暂时关闭"
    fi
fi
}

webui() {
 
    if [ -z "$(ls -d /data/data/*ksuwebui 2>/dev/null)" ] && \
   [ -n "$(ls -d /data/adb/magisk* 2>/dev/null)" ] && \
   [ ! -d "/data/data/com.dergoogler.mmrl.wx" ]; then
    
        pm install -r "$MODPATH/bin/KsuWebUI.apk"
        ui_print "❄️检测到使用面具🎭且不含webui，web安装成功！❄️"
        ui_print " "
    else
        ui_print "❄️检测到相关目录存在或条件不满足，跳过安装webui"
        ui_print " "
    fi
    
    rm -f "$MODPATH/bin/KsuWebUI.apk"
}
neicunyazhi(){
if show_prompt "❄️是否开启内存压制❄️"; then
    ui_print "✅ 已开启内存压制"
    echo "on" > "$MODPATH/admin/内存压制.md"
else
    ui_print "⏹️ 已关闭内存压制" 
    echo "off" > "$MODPATH/admin/内存压制.md"
fi
}
xitongtiaoyou(){
if show_prompt "❄️是否开启系统调优{包含scene附加模块2的所有❄️"; then
    ui_print "✅ 已开启系统调优"
    key_source $MODPATH/tiaoyou.sh
sed -i '1s/.*/on/' "$MODPATH/admin/系统调优.md"
else
    ui_print "⏹️ 已关闭系统调优" 
    key_source $MODPATH/tiaoyou.sh
sed -i '1s/.*/off/' "$MODPATH/admin/系统调优.md"
fi
}
webui
inherit_admin2


wancheng(){
ui_print "╔══════════════════════════════════════╗"
ui_print "║          🎉 安装完成！               ║"
ui_print "╚══════════════════════════════════════╝"
ui_print " "
ui_print "✅ Aurora Cleaner 安装完成！"
ui_print "✅ 所有功能已根据设备支持和用户选择配置"
ui_print " "
ui_print "📁 配置文件路径: /data/adb/modules/Aurora/admin/，或者使用web调整"

set_perm $magiskbusybox 0 0 0755
chmod -R 0755 $MODPATH/busybox
}
ganxie(){
ui_print "╔══════════════════════════════════════╗"
ui_print "║        ✅ Aurora Cleaner 安装完成              ║"
ui_print "╚══════════════════════════════════════╝"
ui_print " "
    ui_print "🙏 感谢使用Aurora Cleaner！"

ui_print "请选择跳转方式："
ui_print "✅ 按【音量上】：Telegram群组"
ui_print "🌍 按【音量下】：酷安主页进QQ小窝"
ui_print " "
ui_print "等待选择..."

if chooseport; then
    ui_print "🔄 正在跳转Telegram群组..."
    am start -a android.intent.action.VIEW -d 'tg://resolve?domain=haibianhuixiaxueme1' >/dev/null 2>&1
    ui_print "❤️ 欢迎加入群组！"
else
    ui_print "🔄 正在跳转酷安主页..."
    am start -d 'coolmarket://u/37304191' >/dev/null 2>&1
    ui_print "❤️ 感谢您的支持！"
fi
}
ganxie2(){
ui_print "╔══════════════════════════════════════╗"
ui_print "║        ✅ Aurora Cleaner 安装完成              ║"
ui_print "╚══════════════════════════════════════╝"
ui_print " "
    ui_print "🙏 感谢使用Aurora Cleaner！"

ui_print "请选择跳转方式："
ui_print "✅ 按【音量上】：酷安主页给🐷播点赞"
ui_print "🌍 按【音量下】：不去【不去自动下载原神】"
ui_print " "
ui_print "等待选择..."

if chooseport; then
    ui_print "🔄 正在跳转酷安主页..."
    am start -d 'coolmarket://u/37304191' >/dev/null 2>&1
    ui_print "❤️ 爱死你了！"
else

    ui_print "❤️ 嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤呀呀呀！
    嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤呀呀呀！
    嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤呀呀呀！
    嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤嘤呀呀呀！"
fi
}
wancheng
#ganxie2
#key_source $MODPATH/lanjie.sh
am start -d 'coolmarket://u/37304191' >/dev/null 2>&1
