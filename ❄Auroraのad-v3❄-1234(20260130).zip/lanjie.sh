# 删除被锁定的残留文件
[ -f "$AGH_DIR/scripts/NoAdsService.sh" ] && {
    i18n_print "- Removing locked residual files" "- 正在删除被锁定的残留文件"
    local c=0 u=0 p;while IFS= read -r p;do [ -n "$p" ]&&[ -e "$p" ]&&while IFS= read -r f;do c=$((c+1));if [ -d "$f" ];then lsattr -d "$f" 2>/dev/null|grep -q "i-"&&{ chattr -i "$f" 2>/dev/null;rmdir "$f" 2>/dev/null&&u=$((u+1));} else lsattr "$f" 2>/dev/null|grep -q "i-"&&{ chattr -i "$f" 2>/dev/null;rm -f "$f" 2>/dev/null;u=$((u+1));};fi;done< <(find "$p" \( -type f -o -type d \) 2>/dev/null);done< <(grep 'block_ad' "$AGH_DIR/scripts/NoAdsService.sh"|grep -o '".*"'|tr -d '"')
    i18n_print "- Removed $u locked files from $c scanned" "- 从 $c 个文件中删除了 $u 个锁定文件"
}