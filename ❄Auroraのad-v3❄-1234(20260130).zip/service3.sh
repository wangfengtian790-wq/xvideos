MODDIR=${0%/*}
handle_config() {
    local config_file="$1" prop_name="$2" script_path="$3"
    local first_line=$(head -n1 "$config_file" 2>/dev/null)
    
    case "$first_line" in
        *on*)
            sed -i "s/${prop_name}:[a-z]*/${prop_name}:on/" /data/adb/modules/Aurora/module.prop

            setsid "$script_path" >/dev/null 2>&1 &
            ;;
        *off*)
         
            sed -i "s/${prop_name}:[a-z]*/${prop_name}:off/" /data/adb/modules/Aurora/module.prop
            ;;
    esac
}
handle_config3() {
    local config_file="$1" script_path="$3"
    local first_line=$(head -n1 "$config_file" 2>/dev/null)
    
    case "$first_line" in
        *on*)
            
            setsid "$script_path" >/dev/null 2>&1 &
            ;;
        *off*)
        
            ;;
    esac
}
sleep 60
setsid "$MODDIR/bin/Ck/Aurora_monitor" >/dev/null 2>&1 &
handle_config "$MODDIR/admin/系统调优.md" "系统调优" "$MODDIR/bin/Tiaoyou/xitongtiaoyou"
sleep 60
setsid "$MODDIR/action2.sh" >/dev/null 2>&1 &
sleep 380
handle_config3 "$MODDIR/admin/Dex2oat.md" "$MODDIR/bin/Trash/dex2"