// b.js - 数据处理函数
// 业务逻辑和数据操作

// 注意：移除了 switchStateCache 和 configCache 缓存对象

// 开关状态管理（移除缓存版本）
async function readSwitchState(filePath) {
    const content = await readFile(filePath);
    let state = 'off';
    
    if (content) {
        const firstLine = content.split('\n')[0].toLowerCase();
        if (firstLine.includes('on')) {
            state = 'on';
        } else if (firstLine.includes('off')) {
            state = 'off';
        }
    }
    
    return state;
}

async function writeSwitchState(filePath, value) {
    const content = await readFile(filePath);
    
    if (!content) return await writeFile(filePath, value);
    
    const lines = content.split('\n');
    if (lines.length > 0) {
        if (lines[0].includes('on')) {
            lines[0] = lines[0].replace('on', 'off');
        } else if (lines[0].includes('off')) {
            lines[0] = lines[0].replace('off', 'on');
        }
    }
    const result = await writeFile(filePath, lines.join('\n'));
    return result;
}

// 配置管理
async function updateConfig(key, value) {
    // 先检查是否是开关
    if (switchFiles[key]) {
        const success = await writeSwitchState(switchFiles[key], value);
        if (success) {
            const name = switchNames[key] || key;
            toast(`${name}已${value === 'on' ? '开启' : '关闭'}`);
            // 立即更新显示
            setTimeout(() => updateConfigDisplay(), 100);
        }
        return success;
    }
    
    // 检查是否是进程模式
    if (key === 'process-mode') {
        return await updateProcessSuppressConfig(key, value);
    }
    
    // 普通配置项
    const configName = configKeys[key];
    if (!configName) {
        toast('配置更新成功');
        return true;
    }

    let content = await readFile(configFile);
    if (!content) {
        content = `${configName}=${value}\n`;
    } else {
        const lines = content.split('\n');
        let found = false;
        const newLines = [];
        
        for (let line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) {
                newLines.push(line);
                continue;
            }
            if (trimmed.startsWith(`${configName}=`)) {
                newLines.push(`${configName}=${value}`);
                found = true;
            } else {
                newLines.push(line);
            }
        }
        
        if (!found) {
            if (newLines.length > 0 && newLines[newLines.length - 1] !== '') newLines.push('');
            newLines.push(`${configName}=${value}`);
        }
        content = newLines.join('\n');
    }
    
    const success = await writeFile(configFile, content);
    if (success) {
        toast(`${configName} 更新为: ${value}`);
        // 立即更新显示
        setTimeout(() => updateConfigDisplay(), 100);
    }
    return success;
}

// 批量更新配置
async function updateConfigs(configs) {
    const results = [];
    for (const [key, value] of Object.entries(configs)) {
        results.push(await updateConfig(key, value));
    }
    return results.every(r => r === true);
}

async function updateProcessSuppressConfig(key, value) {
    const configName = processConfigKeys[key];
    if (!configName) {
        toast('配置更新成功');
        return true;
    }

    const processSuppressFile = `${basePath}/admin/进程压制.md`;
    let content = await readFile(processSuppressFile);
    if (!content) {
        content = `${configName}=${value}\n`;
    } else {
        const lines = content.split('\n');
        let found = false;
        const newLines = [];
        
        for (let line of lines) {
            const trimmed = line.trim();
            if (!trimmed || trimmed.startsWith('#')) {
                newLines.push(line);
                continue;
            }
            if (trimmed.startsWith(`${configName}=`)) {
                newLines.push(`${configName}=${value}`);
                found = true;
            } else {
                newLines.push(line);
            }
        }
        
        if (!found) {
            if (newLines.length > 0 && newLines[newLines.length - 1] !== '') newLines.push('');
            newLines.push(`${configName}=${value}`);
        }
        content = newLines.join('\n');
    }
    
    const success = await writeFile(processSuppressFile, content);
    if (success) {
        toast(`${configName} 更新为: ${value === '1' ? '激进' : '正常'}`);
        // 立即更新显示
        setTimeout(() => updateConfigDisplay(), 100);
    }
    return success;
}

// 脏块设置
async function updateDirtyBlock(mode, trigger, complete) {
    await updateConfig('dirty-mode', mode);
    await updateConfig('dirty-trigger', trigger);
    await updateConfig('dirty-complete', complete);
    
    setTimeout(() => {
        updateConfigDisplay();
    }, 500);
    return true;
}

async function loadDirtyBlockSettings() {
    const content = await readFile(configFile);
    const config = parseConfig(content);
    
    const modeInput = document.getElementById('dirty-mode');
    const triggerInput = document.getElementById('dirty-trigger');
    const completeInput = document.getElementById('dirty-complete');
    
    if (modeInput && config['脏块模式'] !== undefined) {
        modeInput.value = config['脏块模式'];
    }
    if (triggerInput && config['脏块触发阈值'] !== undefined) {
        triggerInput.value = config['脏块触发阈值'];
    }
    if (completeInput && config['脏块完成阈值'] !== undefined) {
        completeInput.value = config['脏块完成阈值'];
    }
}

// 清理执行
async function executeClean(type) {
    let cleaner = cleaners[type];


    const loading = document.getElementById('confirm-modal');
    if (loading) loading.classList.remove('active');
    
    toast('开始执行清理...');
    
    exec(`"${cleaner}" > /dev/null 2>&1 &`);
    setTimeout(() => updateLastCleanTime(type), 1000);
}

async function updateLastCleanTime(type) {
    const content = await readFile(statsFile);
    const stats = parseConfig(content);
    
    const timeKey = timeMap[type];
    const elemId = elemMap[type];
    
    if (timeKey && elemId && stats[timeKey]) {
        const elem = document.getElementById(elemId);
        if (elem) elem.textContent = `上次: ${stats[timeKey]}`;
    }
}

// 数据更新
async function updateStats() {
    const content = await readFile(statsFile);
    const stats = parseConfig(content);
    
    for (const [statKey, elemId] of Object.entries(statMap)) {
        const elem = document.getElementById(elemId);
        if (elem && stats[statKey] !== undefined && stats[statKey] !== '') {
            elem.textContent = elemId.includes('current') || elemId.includes('total') ? 
                `${stats[statKey]}＊1024块` : stats[statKey];
        }
    }
}

async function updateLastCleanTimes() {
    const content = await readFile(statsFile);
    const stats = parseConfig(content);
    
    for (const [timeKey, elemId] of Object.entries(displayTimeMap)) {
        const elem = document.getElementById(elemId);
        if (elem) {
            stats[timeKey] !== undefined && stats[timeKey] !== '' ?
                elem.textContent = `时间: ${stats[timeKey]}` :
                elem.textContent = '时间: 暂无';
        }
    }
}

// 配置显示更新 - 优化版
async function updateConfigDisplay() {
    try {
        const mainContent = await readFile(configFile);
        const mainConfig = parseConfig(mainContent);
        
        let processConfig = {};
        try {
            const processContent = await readFile(`${basePath}/admin/进程压制.md`);
            processConfig = parseConfig(processContent);
        } catch (e) {
            console.log('进程配置文件读取失败');
        }
        
        // 1. 更新开关按钮显示
        const toggleButtons = document.querySelectorAll('.toggle-btn, .mode-btn');
        toggleButtons.forEach(button => {
            const configKey = button.getAttribute('data-config-key');
            if (!configKey) return;
            
            // 检查是否是进程模式
            if (configKey === 'process-mode') {
                const display = processConfig['进程压制方式'] === '1' ? '激进' : '正常';
                button.textContent = display;
                button.setAttribute('data-value', display);
                return;
            }
            
            // 检查是否是开关
            if (switchFiles[configKey]) {
                // 使用setTimeout避免阻塞UI，保持原有逻辑
                setTimeout(async () => {
                    try {
                        const state = await readSwitchState(switchFiles[configKey]);
                        if (button.textContent !== state) {
                            button.textContent = state;
                            button.setAttribute('data-value', state);
                        }
                    } catch (e) {
                        console.error('读取开关状态失败:', configKey, e);
                    }
                }, 0);
                return;
            }
            
            // 普通配置项
            const configName = configKeys[configKey];
            if (configName && mainConfig[configName] !== undefined) {
                const value = mainConfig[configName];
                if (button.textContent !== value) {
                    button.textContent = value;
                    button.setAttribute('data-value', value);
                }
            }
        });
        
        // 2. 更新时间输入框
        const cronInputs = document.querySelectorAll('.cron-input');
        cronInputs.forEach(input => {
            const configKey = input.getAttribute('data-config-key');
            if (configKey) {
                const configName = configKeys[configKey];
                if (configName && mainConfig[configName] !== undefined) {
                    const value = mainConfig[configName];
                    if (input.value !== value) {
                        input.value = value;
                    }
                }
            }
        });
        
        // 3. 更新其他配置显示
        for (const [key, name] of Object.entries(configKeys)) {
            const elem = document.querySelector(`[data-config-key="${key}"]`);
            if (elem && !elem.classList.contains('cron-input') && !elem.classList.contains('toggle-btn')) {
                if (mainConfig[name] !== undefined) {
                    const value = mainConfig[name];
                    if (elem.textContent !== value) {
                        elem.textContent = value;
                        elem.setAttribute('data-value', value);
                    }
                }
            }
        }
        
        // 4. 更新进程配置显示
        for (const [key, name] of Object.entries(processConfigKeys)) {
            const elem = document.querySelector(`[data-config-key="${key}"]`);
            if (elem && key !== 'process-mode') {
                if (processConfig[name] !== undefined) {
                    const value = processConfig[name];
                    if (elem.textContent !== value) {
                        elem.textContent = value;
                        elem.setAttribute('data-value', value);
                    }
                }
            }
        }
        
    } catch (error) {
        console.error('更新配置显示失败:', error);
    }
}

// 刷新所有数据
async function refreshAllData() {
    await updateConfigDisplay();
    await updateStats();
    await updateLastCleanTimes();
    await loadDirtyBlockSettings();
}

// 配置文件操作（移除缓存版本）
async function readConfig(fileName) {
    const path = configFiles[fileName];
    if (!path) {
        return '';
    }
    
    const content = await readFile(path);
    return content || '';
}

async function saveConfig(fileName, content) {
    const path = configFiles[fileName];
    if (!path) {
        return true;
    }
    
    await writeFile(path, content);
    toast('配置文件保存成功');
    return true;
}

// 广告拦截
async function openTestPage() {
    toast('正在打开广告拦截测试页面...');
    await exec('am start -a android.intent.action.VIEW -d "https://paileactivist.github.io/toolz/adblock.html"');
}

async function openManagePage() {
    toast('正在打开广告拦截管理页面...');
    await exec('am start -a android.intent.action.VIEW -d "http://127.0.0.1:3000"');
}

// 日志内容获取
async function getCleanLog() {
    const content = await readFile(logFile);
    if (!content) return '<p>暂无清理日志记录</p>';
    
    const lines = content.split('\n');
    let html = '<div style="max-height:400px;overflow-y:auto;font-family:monospace;font-size:12px;line-height:1.4">';
    lines.forEach(line => {
        if (line.trim()) html += `<p style="margin:4px 0">${line}</p>`;
    });
    return html + '</div>';
}

async function getUpdateLog() {
    const content = await readFile(updateLogFile);
    if (!content) return '<p>暂无更新日志记录</p>';
    
    const lines = content.split('\n');
    let html = '<div style="max-height:400px;overflow-y:auto;font-family:monospace;font-size:12px;line-height:1.4">';
    lines.forEach(line => {
        if (line.trim()) html += `<p style="margin:4px 0">${line}</p>`;
    });
    return html + '</div>';
}

async function getAboutContent() {
    const content = await readFile(aboutFile);
    if (!content) return '<p>暂无关于我们信息</p>';
    
    const lines = content.split('\n');
    let html = '<div style="padding:16px;max-height:400px;overflow-y:auto;">';
    lines.forEach(line => {
        if (line.trim()) html += `<p style="margin:8px 0;line-height:1.6">${line}</p>`;
    });
    return html + '</div>';
}

async function loadDonateImage() {
    const { errno, stdout } = await exec(`base64 -w 0 "${donateImage}"`);
    if (errno === 0 && stdout) {
        const img = document.getElementById('donate-img');
        if (img) img.src = `data:image/jpeg;base64,${stdout}`;
    }
}

// 关键：导出所有函数到全局！！！
window.readSwitchState = readSwitchState;
window.writeSwitchState = writeSwitchState;
window.updateConfig = updateConfig;
window.updateConfigs = updateConfigs; // 新增的批量更新函数
window.updateProcessSuppressConfig = updateProcessSuppressConfig;
window.updateDirtyBlock = updateDirtyBlock;
window.loadDirtyBlockSettings = loadDirtyBlockSettings;
window.executeClean = executeClean;
window.updateLastCleanTime = updateLastCleanTime;
window.updateStats = updateStats;
window.updateLastCleanTimes = updateLastCleanTimes;
window.updateConfigDisplay = updateConfigDisplay;
window.refreshAllData = refreshAllData;
window.readConfig = readConfig;
window.saveConfig = saveConfig;
window.openTestPage = openTestPage;
window.openManagePage = openManagePage;
window.getCleanLog = getCleanLog;
window.getUpdateLog = getUpdateLog;
window.getAboutContent = getAboutContent;
window.loadDonateImage = loadDonateImage;