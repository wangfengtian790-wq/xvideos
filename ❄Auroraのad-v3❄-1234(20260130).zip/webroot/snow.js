// 延迟3秒执行整个雪花效果
setTimeout(function() {
    (function() {
        'use strict';
        initSnow();
        
        function initSnow() {
            const container = document.createElement('div');
            container.id = 'snow-container';
            Object.assign(container.style, {
                position: 'fixed',
                top: '0',
                left: '0',
                width: '100%',
                height: '100%',
                pointerEvents: 'none',
                zIndex: '-1',
                overflow: 'hidden'
            });
            document.body.appendChild(container);
            
            const snowCount = Math.max(30, Math.min(10, Math.floor(window.innerWidth / 40)));
            const snowflakes = new Array(snowCount);
            
            const viewHeight = window.innerHeight;
            const viewWidth = window.innerWidth;
            
            const fragment = document.createDocumentFragment();
            
            for (let i = 0; i < snowCount; i++) {
                const flake = document.createElement('div');
                flake.textContent = '❄️';
                
                const opacity = 0.6 + Math.random() * 0.4;
                
                Object.assign(flake.style, {
                    position: 'absolute',
                    fontSize: `${16 + Math.random() * 8}px`,
                    opacity: opacity,
                    userSelect: 'none',
                    pointerEvents: 'none',
                    willChange: 'transform, opacity',
                    textShadow: '0 0 6px #ffc0cb, 0 0 4px #1e90ff'
                });
                
                fragment.appendChild(flake);
                
                snowflakes[i] = {
                    el: flake,
                    x: Math.random() * viewWidth,
                    y: -20 - Math.random() * 100,
                    speed: 0.8 + Math.random() * 1.2,
                    sway: Math.random() * 2 - 1,
                    swaySpeed: 0.0005 + Math.random() * 0.001,
                    baseOpacity: opacity
                };
            }
            
            container.appendChild(fragment);
            
            let animationId;
            let lastTime = performance.now();
            
            function animate(currentTime) {
                const delta = Math.min(currentTime - lastTime, 32);
                lastTime = currentTime;
                
                for (let i = 0; i < snowflakes.length; i++) {
                    const flake = snowflakes[i];
                    
                    flake.y += flake.speed * (delta * 0.05);
                    
                    const swayOffset = Math.sin(currentTime * flake.swaySpeed) * flake.sway;
                    flake.x += swayOffset * 0.9;
                    
                    if (flake.y > viewHeight + 100) {
                        flake.y = -50;
                        flake.x = Math.random() * viewWidth;
                    }
                    
                    flake.el.style.transform = `translate(${flake.x}px, ${flake.y}px)`;
                    
                    const progress = flake.y / viewHeight;
                    if (progress < 0.1) {
                        flake.el.style.opacity = progress * 10 * flake.baseOpacity;
                    } else if (progress > 0.85) {
                        flake.el.style.opacity = (1 - progress) * 6.67 * flake.baseOpacity;
                    }
                }
                
                animationId = requestAnimationFrame(animate);
            }
            
            animationId = requestAnimationFrame(animate);
            
            let hidden = false;
            document.addEventListener('visibilitychange', () => {
                if (document.hidden && !hidden) {
                    hidden = true;
                    cancelAnimationFrame(animationId);
                } else if (!document.hidden && hidden) {
                    hidden = false;
                    lastTime = performance.now();
                    animationId = requestAnimationFrame(animate);
                }
            });
            
            let resizeDebounce;
            window.addEventListener('resize', () => {
                clearTimeout(resizeDebounce);
                resizeDebounce = setTimeout(() => {
                    const newWidth = window.innerWidth;
                    const newHeight = window.innerHeight;
                    
                    for (let i = 0; i < snowflakes.length; i++) {
                        const flake = snowflakes[i];
                        if (flake.x > newWidth || flake.y > newHeight) {
                            flake.x = Math.random() * newWidth;
                            flake.y = -50;
                        }
                    }
                }, 200);
            });
        }
    })();
}, 1000); 