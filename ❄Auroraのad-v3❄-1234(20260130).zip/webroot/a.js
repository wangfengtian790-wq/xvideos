// a.js - 全局核心函数
// 基础设施和工具函数，改动最少的部分

let exec, toast;

// KSU环境初始化
function initKsu() {
    if (typeof window.ksu !== 'undefined') {
        exec = async cmd => new Promise((resolve, reject) => {
            const callbackName = `cb_${Date.now()}`;
            window[callbackName] = (errno, stdout, stderr) => {
                resolve({ errno, stdout, stderr });
                delete window[callbackName];
            };
            try {
                window.ksu.exec(cmd, '{}', callbackName);
            } catch (e) {
                reject(e);
                delete window[callbackName];
            }
        });
        toast = msg => {
            window.ksu && window.ksu.toast && window.ksu.toast(msg);
        };
    } else {
        exec = async cmd => ({ errno: 0, stdout: 'simulation', stderr: '' });
        toast = msg => {};
    }
}

// 基础文件操作
async function readFile(path) {
    const { errno, stdout } = await exec(`cat "${path}"`);
    return errno === 0 ? stdout : '';
}

async function writeFile(path, content) {
    const escapedPath = path.replace(/'/g, "'\"'\"'")
                          .replace(/"/g, '\\"');
    // 使用 printf
    const { errno } = await exec(`printf '%s' '${content.replace(/'/g, "'\"'\"'")}' > "${escapedPath}"`);
    return errno === 0;
}
// 配置解析
function parseConfig(content) {
    const config = {};
    if (!content) return config;
    
    const lines = content.split('\n');
    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        
        if (trimmed.includes('=')) {
            const eqIndex = trimmed.indexOf('=');
            const key = trimmed.substring(0, eqIndex).trim();
            const value = trimmed.substring(eqIndex + 1).trim();
            config[key] = value;
        }
    }
    return config;
}

// 路径常量
const basePath = '/data/adb/modules/Aurora';
const configFile = `${basePath}/admin/配置文件.md`;
const statsFile = `${basePath}/stats`;
const logFile = `${basePath}/log.md`;
const updateLogFile = `${basePath}/更新日志/更新日志.md`;
const aboutFile = `${basePath}/更新日志/关于我们.md`;
const donateImage = `${basePath}/webroot/123.jpg`;

// a.js - 清理器映射
const cleaners = {
    'scan': `${basePath}/bin/Trash/scan_cleaner`,
    'empty-file': `${basePath}/bin/Empty/empty_cleaner`,
    'dirty-block': `${basePath}/bin/Trash/f2fs`,
    'regular': `${basePath}/bin/Trash/trash_cleaner`,
    'wechat-deep': `${basePath}/bin/Trash/wx_cleaner`,
    'qq-deep': `${basePath}/bin/Trash/qq_cleaner`,
    'app-cache': `${basePath}/bin/Trash/app_cleaner`,
    'system-cache': `${basePath}/bin/Trash/system_cleaner`,
    'guilei': `${basePath}/bin/Trash/guilei`,
    'dex2': `${basePath}/bin/Trash/dex2`
};
// 配置键映射
const configKeys = {
    'scan-toggle': '扫描清理', 'scan-cron': '扫描时间',
    'empty-toggle': '清理空文件', 'empty-cron': '空文件时间',
    'dirty-toggle': '清理脏块', 'dirty-cron': '脏块检查时间',
    'dirty-mode': '脏块模式', 'dirty-trigger': '脏块触发阈值', 'dirty-complete': '脏块完成阈值',
    'regular-toggle': '清理垃圾', 'regular-cron': '垃圾时间',
    'wechat-toggle': '微信清理', 'wechat-cron': '微信时间',
    'qq-toggle': 'QQ清理', 'qq-cron': 'QQ时间',
    'app-toggle': '应用缓存清理', 'app-cron': '应用缓存时间',
    'system-toggle': '系统缓存清理', 'system-cron': '系统缓存时间',
    'guilei-toggle': '文件归类', 'guilei-cron': '归类时间'
};

// 配置文件映射
const configFiles = {
    '扫描清理.md': `${basePath}/admin/扫描清理.md`,
    '黑名单.md': `${basePath}/admin/white_black/黑名单.md`,
    '白名单.md': `${basePath}/admin/white_black/白名单.md`,
    'MounterMover.md': `${basePath}/admin/MounterMover.md`,
    '系统调优.md': `${basePath}/admin/系统调优.md`,
    '文件归类.md': `${basePath}/admin/文件归类.md`,
    '进程压制.md': `${basePath}/admin/进程压制.md`,
    'Dex2oat.md': `${basePath}/admin/Dex2oat.md`
};

// 开关文件映射
const switchFiles = {
    'process-toggle': `${basePath}/admin/进程压制.md`,
    'memory-toggle': `${basePath}/admin/内存压制.md`,
    'optimize-toggle': `${basePath}/admin/系统调优.md`,
    'ad-toggle': `${basePath}/admin/广告拦截.md`,
    'mounter-toggle': `${basePath}/admin/MounterMover.md`,
    'wencong-toggle': `${basePath}/admin/通知.md`
};

// 开关名称映射
const switchNames = {
    'process-toggle': '进程压制',
    'memory-toggle': '内存压制',
    'optimize-toggle': '系统调优',
    'ad-toggle': '广告拦截',
    'mounter-toggle': 'MounterMover',
    'wencong-toggle': '状态栏通知'
};

// 进程配置键
const processConfigKeys = {
    'process-toggle': '压制进程',
    'process-mode': '进程压制方式'
};

// 时间映射
const timeMap = {
    'scan': 'last_scan', 'empty-file': 'last_empty', 'dirty-block': 'last_f2fs',
    'regular': 'last_regular', 'wechat-deep': 'last_wx', 'qq-deep': 'last_qq',
    'app-cache': 'last_app', 'system-cache': 'last_system', 'guilei': 'last_guilei',
    'dex2': 'last_dex2oat'
};

// 统计映射
const statMap = {
    'trash': 'trash-count', 'empty_files': 'empty-files-count', 'empty_dirs': 'empty-dirs-count',
    'dirty_gb': 'dirty-current', 'total_cleaned_gb': 'dirty-total', 'process': 'process-count',
    'guilei_files': 'guilei-count'
};

// 显示时间映射
const displayTimeMap = {
    'last_scan': 'last-scan', 'last_empty': 'last-empty', 'last_app': 'last-app',
    'last_f2fs': 'last-dirty', 'last_system': 'last-system', 'last_regular': 'last-regular',
    'last_wx': 'last-wechat', 'last_qq': 'last-qq', 'last_guilei': 'last-guilei', 'last_dex2oat': 'last-dex2oat'
};

// 清理类型到元素ID的映射
const elemMap = {
    'scan': 'last-scan', 'empty-file': 'last-empty', 'dirty-block': 'last-dirty',
    'regular': 'last-regular', 'wechat-deep': 'last-wechat', 'qq-deep': 'last-qq',
    'app-cache': 'last-app', 'system-cache': 'last-system', 'guilei': 'last-guilei',
    'dex2': 'last-dex2oat'
};

// 导出全局函数
window.initKsu = initKsu;
window.readFile = readFile;
window.writeFile = writeFile;
window.parseConfig = parseConfig;

// 初始化KSU
initKsu();
window.exec = exec;
window.toast = toast;

// 关键：导出所有常量！！！
window.basePath = basePath;
window.configFile = configFile;
window.statsFile = statsFile;
window.configKeys = configKeys;
window.configFiles = configFiles;
window.switchFiles = switchFiles;
window.switchNames = switchNames;
window.processConfigKeys = processConfigKeys;
window.timeMap = timeMap;
window.statMap = statMap;
window.displayTimeMap = displayTimeMap;
window.elemMap = elemMap;
window.cleaners = cleaners;