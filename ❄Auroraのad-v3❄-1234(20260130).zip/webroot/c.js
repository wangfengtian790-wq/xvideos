// c.js - 样式和主题函数
// UI样式、主题和背景处理

// 背景图片处理
async function loadBackgroundImage() {
    const cachedBackground = localStorage.getItem('cached_background');
    
    if (cachedBackground) {
        document.body.style.backgroundImage = `url(${cachedBackground})`;
        return;
    }
    
    const { errno, stdout } = await exec(`base64 -w 0 "/data/adb/modules/Aurora/admin/background.jpg"`);
    if (errno === 0 && stdout) {
        const backgroundData = `data:image/jpeg;base64,${stdout}`;
        
        localStorage.setItem('cached_background', backgroundData);
        
        document.body.style.backgroundImage = `url(${backgroundData})`;
    }
}

async function clearBackgroundCache() {
    localStorage.removeItem('cached_background');
    await loadBackgroundImage();
    toast('背景缓存已清除');
}

// 深色模式
async function toggleDarkMode(enable) {
    localStorage.setItem('aurora_dark_mode', enable);
    
    if (enable) {
        document.documentElement.dataset.theme = 'dark';
        document.body.classList.add('dark-mode');
        toast('已开启深色模式');
    } else {
        document.documentElement.dataset.theme = 'light';
        document.body.classList.remove('dark-mode');
        toast('已关闭深色模式');
    }
    
    // 重新应用透明度
    const savedOpacity = localStorage.getItem('aurora_opacity');
    if (savedOpacity) {
        applyDynamicOpacity(parseInt(savedOpacity));
    }
}

async function initDarkMode() {
    const isDarkMode = localStorage.getItem('aurora_dark_mode') === 'true';
    
    if (isDarkMode) {
        document.documentElement.dataset.theme = 'dark';
        document.body.classList.add('dark-mode');
    } else {
        document.documentElement.dataset.theme = 'light';
        document.body.classList.remove('dark-mode');
    }
    
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    if (darkModeToggle) {
        darkModeToggle.textContent = isDarkMode ? 'on' : 'off';
        darkModeToggle.setAttribute('data-value', isDarkMode ? 'on' : 'off');
    }
}

function applyDynamicOpacity(opacityPercent) {
    const opacityValue = opacityPercent / 100;
    const isDarkMode = document.body.classList.contains('dark-mode');
    
    // 创建样式表一次性应用（更高效）
    const styleId = 'aurora-dynamic-opacity';
    let style = document.getElementById(styleId);
    
    if (!style) {
        style = document.createElement('style');
        style.id = styleId;
        document.head.appendChild(style);
    }
    
    // 一次性生成所有CSS
    const css = `
        ${isDarkMode ? 'body.dark-mode ' : ''}.app-header,
        ${isDarkMode ? 'body.dark-mode ' : ''}.stat-item,
        ${isDarkMode ? 'body.dark-mode ' : ''}.clean-item,
        ${isDarkMode ? 'body.dark-mode ' : ''}.setting-item,
        ${isDarkMode ? 'body.dark-mode ' : ''}.profile-item,
        ${isDarkMode ? 'body.dark-mode ' : ''}.bottom-nav,
        ${isDarkMode ? 'body.dark-mode ' : ''}.clean-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.config-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.threshold-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.test-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.cancel-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.confirm-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.toggle-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.mode-btn,
        ${isDarkMode ? 'body.dark-mode ' : ''}.refresh-btn {
            background: ${isDarkMode ? `rgba(50, 50, 50, ${opacityValue * 0.8})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
            border: 2px solid ${isDarkMode ? `rgba(100, 100, 100, ${opacityValue * 0.8})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
        }
        
        ${isDarkMode ? 'body.dark-mode ' : ''}.cron-input {
            background: ${isDarkMode ? `rgba(70, 70, 70, ${opacityValue})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
            border: 1px solid ${isDarkMode ? `rgba(150, 150, 150, ${opacityValue})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
        }
        
        ${isDarkMode ? 'body.dark-mode ' : ''}.modal-content {
            background: ${isDarkMode ? `rgba(30, 30, 30, ${Math.min(opacityValue * 0.8 + 0.4, 0.95)})` : `rgba(255, 255, 255, ${Math.min(opacityValue + 0.4, 0.95)})`} !important;
            border: 1px solid ${isDarkMode ? `rgba(100, 100, 100, ${Math.min(opacityValue * 0.8 + 0.4, 0.95)})` : `rgba(255, 255, 255, ${Math.min(opacityValue + 0.4, 0.95)})`} !important;
        }
        
        ${isDarkMode ? 'body.dark-mode ' : ''}.toggle-options,
        ${isDarkMode ? 'body.dark-mode ' : ''}.mode-options {
            background: ${isDarkMode ? `rgba(60, 60, 60, ${opacityValue * 0.8})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
            border: 1px solid ${isDarkMode ? `rgba(100, 100, 100, ${opacityValue * 0.8})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
        }
        
        ${isDarkMode ? 'body.dark-mode ' : ''}.toggle-option,
        ${isDarkMode ? 'body.dark-mode ' : ''}.mode-option {
            background: ${isDarkMode ? `rgba(70, 70, 70, ${opacityValue * 0.8})` : `rgba(255, 255, 255, ${opacityValue})`} !important;
        }
    `;
    
    style.textContent = css;
    localStorage.setItem('aurora_opacity', opacityPercent.toString());
}

// 初始化透明度
async function initOpacity() {
    const savedOpacity = localStorage.getItem('aurora_opacity');
    if (savedOpacity !== null) {
        const opacityPercent = parseInt(savedOpacity);
        if (!isNaN(opacityPercent) && opacityPercent >= 0 && opacityPercent <= 100) {
            // 应用动态透明度
            applyDynamicOpacity(opacityPercent);
            
            // 更新滑块显示
            const opacitySlider = document.getElementById('opacity-slider');
            const opacityValue = document.getElementById('opacity-value');
            if (opacitySlider && opacityValue) {
                opacitySlider.value = opacityPercent;
                opacityValue.textContent = `${opacityPercent}%`;
            }
        }
    }
}



// 页面内容显示
async function showSection(section) {
    if (section === 'clean-log') {
        const content = await getCleanLog();
        document.getElementById('detail-content').innerHTML = content;
    } else if (section === 'update-log') {
        const content = await getUpdateLog();
        document.getElementById('detail-content').innerHTML = content;
    } else if (section === 'about') {
        const content = await getAboutContent();
        document.getElementById('detail-content').innerHTML = content;
    } else if (section === 'donate') {
        await loadDonateImage();
    } else if (section === 'clear-bg-cache') {
        await clearBackgroundCache();
    }
}

// 导出函数
window.loadBackgroundImage = loadBackgroundImage;
window.clearBackgroundCache = clearBackgroundCache;
window.toggleDarkMode = toggleDarkMode;
window.initDarkMode = initDarkMode;
window.applyDynamicOpacity = applyDynamicOpacity;
window.initOpacity = initOpacity;

window.showSection = showSection;