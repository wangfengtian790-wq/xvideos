// d.js - UI事件处理
// DOM事件绑定和交互逻辑

document.addEventListener('DOMContentLoaded', function() {
    // 初始化深色模式
    if (window.initDarkMode) {
        window.initDarkMode();
    }
    
    // 初始化透明度
    if (window.initOpacity) {
        window.initOpacity();
    }
    
    // 加载背景图片
    if (window.loadBackgroundImage) {
        window.loadBackgroundImage();
    }
    
    // 页面导航
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');
    
    navItems.forEach(tab => {
        tab.addEventListener('click', function() {
            const pageId = this.getAttribute('data-page');
            navItems.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            pages.forEach(page => {
                page.classList.remove('active');
                if (page.id === pageId) page.classList.add('active');
            });
        });
    });
    
    // 刷新按钮
    const refreshBtn = document.getElementById('refresh-btn');
    refreshBtn.addEventListener('click', function() {
        if (window.refreshAllData) {
            window.refreshAllData();
        }
    });
    
    // 开关组件初始化（这部分适合单独绑定）
    const toggleGroups = document.querySelectorAll('.toggle-group, .mode-group');
    
    function initToggle(group) {
        group.forEach(container => {
            const button = container.querySelector('.toggle-btn, .mode-btn');
            const dropdown = container.querySelector('.toggle-options, .mode-options');
            
            if (!button || !dropdown) return;
            
            function updateDropdown() {
                const currentValue = button.textContent;
                const option = dropdown.querySelector('.toggle-option, .mode-option');
                if (!option) return;
                
                if (button.classList.contains('toggle-btn')) {
                    const newValue = currentValue === 'on' ? 'off' : 'on';
                    option.textContent = newValue;
                    option.setAttribute('data-value', newValue);
                } else if (button.classList.contains('mode-btn')) {
                    const newValue = currentValue === '激进' ? '正常' : '激进';
                    option.textContent = newValue;
                    option.setAttribute('data-value', newValue);
                }
            }
            
            updateDropdown();
            
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                updateDropdown();
                
                document.querySelectorAll('.toggle-options.active, .mode-options.active').forEach(drop => {
                    if (drop !== dropdown) drop.classList.remove('active');
                });
                
                dropdown.classList.toggle('active');
            });
            
            const options = dropdown.querySelectorAll('.toggle-option, .mode-option');
            options.forEach(option => {
                option.addEventListener('click', function() {
                    const newValue = this.getAttribute('data-value');
                    button.textContent = newValue;
                    button.setAttribute('data-value', newValue);
                    dropdown.classList.remove('active');
                    updateDropdown();
                    
                    const configKey = button.getAttribute('data-config-key');
                    
                    if (button.id === 'dark-mode-toggle') {
                        if (window.toggleDarkMode) {
                            window.toggleDarkMode(newValue === 'on');
                        }
                    } 
                    else if (button.classList.contains('mode-btn')) {
                        const configValue = newValue === '激进' ? '1' : '0';
                        if (configKey && window.updateConfig) {
                            window.updateConfig(configKey, configValue);
                        }
                    }
                    else if (configKey && window.updateConfig) {
                        window.updateConfig(configKey, newValue);
                    }
                });
            });
        });
    }
    
    initToggle(toggleGroups);
    
    // 关闭所有下拉菜单
    document.addEventListener('click', function() {
        document.querySelectorAll('.toggle-options.active, .mode-options.active').forEach(dropdown => {
            dropdown.classList.remove('active');
        });
    });
    
    // 定时输入框（保留单独绑定，因为需要change事件）
    const cronInputs = document.querySelectorAll('.cron-input');
    cronInputs.forEach(input => {
        input.addEventListener('change', function() {
            const configKey = this.getAttribute('data-config-key');
            const value = this.value.trim();
            if (configKey && value && window.updateConfig) {
                window.updateConfig(configKey, value);
            }
        });
    });
    
    // ========== 事件委托部分 ==========
    // 用于存储当前操作的类型
    let currentCleanType = '';
    let currentConfigFile = '';
    
    // 主事件委托监听器
    document.addEventListener('click', function(e) {
        // 1. 清理按钮
        if (e.target.classList.contains('clean-btn') || e.target.closest('.clean-btn')) {
            const button = e.target.classList.contains('clean-btn') ? e.target : e.target.closest('.clean-btn');
            const parent = button.closest('.clean-item');
            currentCleanType = parent.getAttribute('data-type');
            const title = parent.querySelector('.clean-name').textContent;
            document.getElementById('confirm-message').textContent = `确定要执行${title}吗？`;
            document.getElementById('confirm-modal').classList.add('active');
            e.stopPropagation();
            return;
        }
        
        // 2. 配置按钮
        if (e.target.classList.contains('config-btn') || e.target.closest('.config-btn')) {
            const button = e.target.classList.contains('config-btn') ? e.target : e.target.closest('.config-btn');
            const fileName = button.getAttribute('data-file');
            currentConfigFile = fileName;
            const parent = button.closest('.setting-item');
            const title = parent.querySelector('.setting-name').textContent;
            document.getElementById('config-title').textContent = `${title}配置`;
            if (window.readConfig) {
                window.readConfig(fileName).then(content => {
                    document.getElementById('config-textarea').value = content;
                    document.getElementById('config-modal').classList.add('active');
                });
            }
            e.stopPropagation();
            return;
        }
        
        // 3. 脏块设置按钮
        if (e.target.classList.contains('threshold-btn') || e.target.closest('.threshold-btn')) {
            if (window.loadDirtyBlockSettings) {
                window.loadDirtyBlockSettings();
            }
            document.getElementById('threshold-modal').classList.add('active');
            e.stopPropagation();
            return;
        }
        
        // 4. 个人页面项目
        if (e.target.classList.contains('profile-item') || e.target.closest('.profile-item')) {
            const item = e.target.classList.contains('profile-item') ? e.target : e.target.closest('.profile-item');
            const profileType = item.getAttribute('data-type');
            
            if (profileType === 'clean-log') {
                document.getElementById('detail-title').textContent = '清理日志';
                document.getElementById('detail-content').innerHTML = '<p style="padding:20px;text-align:center">加载中...</p>';
                if (window.showSection) {
                    window.showSection('clean-log');
                }
            } else if (profileType === 'update-log') {
                document.getElementById('detail-title').textContent = '更新日志';
                document.getElementById('detail-content').innerHTML = '<p style="padding:20px;text-align:center">加载中...</p>';
                if (window.showSection) {
                    window.showSection('update-log');
                }
            } else if (profileType === 'about') {
                document.getElementById('detail-title').textContent = '关于我们';
                document.getElementById('detail-content').innerHTML = '<p style="padding:20px;text-align:center">加载中...</p>';
                if (window.showSection) {
                    window.showSection('about');
                }
            } else if (profileType === 'donate') {
                document.getElementById('detail-title').textContent = '捐贈をする支持';
                document.getElementById('detail-content').innerHTML = '<div class="donate-content"><p class="donate-text">感谢您对Aurora清理工具の支持！您の捐贈をする将帮助我们持续开发和改进这个项目。</p><div class="donate-image"><img id="donate-img" src="" style="width:200px;height:200px;border-radius:10px"></div></div>';
                if (window.showSection) {
                    window.showSection('donate');
                }
            } else if (profileType === 'clear-bg-cache') {
                document.getElementById('detail-title').textContent = '清除背景缓存';
                document.getElementById('detail-content').innerHTML = `
                    <div style="padding: 30px; text-align: center; line-height: 1.6;">
                        <p>把你の图片重命名background.jpg替换到/data/adb/modules/Aurora/admin/background.jpg文件,</p>
                        <p>然后点击这个清理存储器缓存</p>
                        <p>为什么这样，因为存储到浏览器里面，可以让你后续每次进入加载图片没延迟</p>
                    </div>
                `;
                if (window.clearBackgroundCache) {
                    window.clearBackgroundCache();
                }
            }
            document.getElementById('detail-modal').classList.add('active');
            e.stopPropagation();
            return;
        }
        
        // 5. 模态框关闭（点击背景）
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('active');
            return;
        }
        
        // 6. 确认按钮
        if (e.target.id === 'confirm-btn' || e.target.closest('#confirm-btn')) {
            if (window.executeClean) {
                window.executeClean(currentCleanType);
            }
            document.getElementById('confirm-modal').classList.remove('active');
            return;
        }
        
        // 7. 取消按钮
        if (e.target.id === 'cancel-btn' || e.target.closest('#cancel-btn')) {
            document.getElementById('confirm-modal').classList.remove('active');
            return;
        }
        
        // 8. 保存脏块设置
        if (e.target.id === 'save-threshold' || e.target.closest('#save-threshold')) {
            const mode = document.getElementById('dirty-mode').value;
            const trigger = document.getElementById('dirty-trigger').value;
            const complete = document.getElementById('dirty-complete').value;
            if (mode && trigger && complete && window.updateDirtyBlock) {
                window.updateDirtyBlock(mode, trigger, complete);
                document.getElementById('threshold-modal').classList.remove('active');
            }
            return;
        }
        
        // 9. 取消脏块设置
        if (e.target.id === 'cancel-threshold' || e.target.closest('#cancel-threshold')) {
            document.getElementById('threshold-modal').classList.remove('active');
            return;
        }
        
        // 10. 保存配置
        if (e.target.id === 'save-config' || e.target.closest('#save-config')) {
            const content = document.getElementById('config-textarea').value;
            if (window.saveConfig) {
                window.saveConfig(currentConfigFile, content);
            }
            document.getElementById('config-modal').classList.remove('active');
            return;
        }
        
        // 11. 取消配置
        if (e.target.id === 'cancel-config' || e.target.closest('#cancel-config')) {
            document.getElementById('config-modal').classList.remove('active');
            return;
        }
        
        // 12. 关闭详情
        if (e.target.id === 'close-detail' || e.target.closest('#close-detail')) {
            document.getElementById('detail-modal').classList.remove('active');
            return;
        }
    });
    // ========== 事件委托部分结束 ==========
    
    // 透明度滑块（使用防抖优化）
    const opacitySlider = document.getElementById('opacity-slider');
    const opacityValue = document.getElementById('opacity-value');
    
    if (opacitySlider && opacityValue) {
        const savedOpacity = localStorage.getItem('aurora_opacity');
        if (savedOpacity !== null) {
            const opacityPercent = parseInt(savedOpacity);
            if (!isNaN(opacityPercent) && opacityPercent >= 0 && opacityPercent <= 100) {
                opacitySlider.value = opacityPercent;
                opacityValue.textContent = `${opacityPercent}%`;
            }
        }
        
        // 防抖函数
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        // 创建防抖版本
        const debouncedOpacityUpdate = debounce((opacityPercent) => {
            if (window.applyDynamicOpacity) {
                window.applyDynamicOpacity(opacityPercent);
                if (typeof toast === 'function') {
                    toast(`不透明度已设置为${opacityPercent}%`);
                }
            }
        }, 800);
        
        opacitySlider.addEventListener('input', function() {
            const opacityPercent = parseInt(this.value);
            opacityValue.textContent = `${opacityPercent}%`;
            
            // 立即应用透明度（实时反馈）
            if (window.applyDynamicOpacity) {
                window.applyDynamicOpacity(opacityPercent);
            }
            
            // 防抖保存和toast
            debouncedOpacityUpdate(opacityPercent);
        });
        
        opacitySlider.addEventListener('change', function() {
            const opacityPercent = parseInt(this.value);
            
            // 立即保存和显示toast
            if (window.applyDynamicOpacity) {
                window.applyDynamicOpacity(opacityPercent);
                if (typeof toast === 'function') {
                    toast(`不透明度已设置为${opacityPercent}%`);
                }
            }
        });
    }
    
    // 启动初始化脚本
  //  if (window.exec) {
      //  window.exec(` "/data/adb/modules/Aurora/action2.sh" > /dev/null 2>&1 &`);
 //   }
    
    // 延迟加载数据
    setTimeout(() => {
        if (window.refreshAllData) {
            window.refreshAllData();
        }
    }, 500);
});