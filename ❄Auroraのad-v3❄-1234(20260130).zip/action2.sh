#!/system/bin/sh

MODDIR=${0%/*}


if [ -f "$MODDIR/admin/通知.md" ]; then
    FIRST_LINE="$(head -n 1 "$MODDIR/admin/通知.md" 2>/dev/null | tr -d '[:space:]')"
else
    FIRST_LINE="off"
fi

[ "$FIRST_LINE" != "on" ] && exit 0

# 后台执行
{
  
    CURRENT_VERSION="$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d'=' -f2)"
    UPDATE_URL="$(grep '^updateJson=' "$MODDIR/module.prop" 2>/dev/null | cut -d'=' -f2)"
    
  
    LATEST_VERSION="$(curl -s "$UPDATE_URL" 2>/dev/null | grep -o '\"versionCode\":[0-9]*' | cut -d: -f2)"
    

    for i in 1 2 3 4 5; do
        pidof Aurora_timed >/dev/null 2>&1 && {
            IS_RUNNING=true
            break
        }
        [ $i -lt 5 ] && sleep 10
    done
    

    if [ "$CURRENT_VERSION" = "$LATEST_VERSION" ]; then
        TITLE="🏔️Aurora🏔最新版本"
    else
        TITLE="🏔️Aurora🏔待更新"
    fi
    
    if [ "$IS_RUNNING" = true ]; then
        TEXT="❄️Aurora_timed低开销定时正在运行❄️"
    else
        TEXT="❄️Aurora_timed低开销定时未运行❄️"
    fi
    
    
    su 2000 -c "cmd notification post -S messaging --conversation \"$TITLE\" --message \"$TITLE\":\"$TEXT\" \"Tag\" \"\$RANDOM\"" >/dev/null 2>&1
} &


exit 0