off

#qq和tim下载目录的zip和apk文件
/storage/emulated/0/Android/data/com.tencent.*/Tencent/*file_recv+*.zip&&*.apk+/storage/emulated/0/Aurora/QQ/
#纸飞机下载目录
/storage/emulated/0/Android/data/*telegram*/files/Telegram/Telegram Files/+/storage/emulated/0/Aurora/telegram/
#应用宝下载目录
/storage/emulated/0/Android/data/com.tencent.android.qqdownloader/files/tassistant/apk/+/storage/emulated/0/Aurora/apk
/storage/emulated/0/Android/data/*/files/Download+/storage/emulated/0/Aurora/Download/

#开关只能放在第一行on或者off。👇🏻配置介绍

#mount=源路径+目标路径这个代表用挂载的方式实现，这个不支持&&。
#源目录路径+目标目录路径   代表把源目录路径里面的文件到+号右边目标目录里
#源目录1路径&&源目录2路径+目标路径  表示把多个源目录路径移动到目标目录路径，&&代表和的意思
#路径&&路径+特定规则+目标路径 表示只移动特定规则的文件到右边。特定规则支持通配符*，比如＊.apk，然后特定规则也支持&&，&&代表和的意思
#你可以自己更改目标路径

