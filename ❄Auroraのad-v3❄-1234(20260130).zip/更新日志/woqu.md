#!/system/bin/sh
# 获取六个存储核心参数

echo "📱 存储六参数"
echo "============"

df -k 2>/dev/null | awk '
# 只统计物理分区
$1 ~ /^\/dev\/block\// {
    # 所有物理分区的统计
    physical_size += $2
    physical_used += $3
    
    # 用户数据分区
    if ($6 == "/data") {
        user_size = $2
        user_used = $3
        user_free = $4
    }
    
    # 系统分区使用量（排除/data）
    if ($6 != "/data") {
        system_used += $3
    }
}
END {
    # 验证数据
    if (physical_size <= 0) {
        print "错误：未找到物理分区"
        exit 1
    }
    
    # 六个参数计算
    # 1. 手机总容量（厂商标称）
    total_nominal = 256
    
    # 2. 读取到的总容量（实际统计）
    read_total_gb = physical_size / 1048576
    
    # 3. 已使用总量（用户+系统）
    total_used_gb = (user_used + system_used) / 1048576
    
    # 4. 未使用总量（从/data分区获取）
    total_free_gb = user_free / 1048576
    
    # 5. 用户数据已用
    user_used_gb = user_used / 1048576
    
    # 6. 系统数据已用
    system_used_gb = system_used / 1048576
    
    # 输出结果
    printf "┌─────────────────────────────────┐\n"
    printf "│       存储核心六参数             │\n"
    printf "├─────────────────────────────────┤\n"
    printf "│ 1. 手机总容量：    %6.0f GB    │\n", total_nominal
    printf "│ 2. 读取总容量：    %6.1f GB    │\n", read_total_gb
    printf "│ 3. 已使用总量：    %6.1f GB    │\n", total_used_gb
    printf "│ 4. 未使用总量：    %6.1f GB    │\n", total_free_gb
    printf "│ 5. 用户数据已用：  %6.1f GB    │\n", user_used_gb
    printf "│ 6. 系统数据已用：  %6.1f GB    │\n", system_used_gb
    printf "└─────────────────────────────────┘\n"
    
    # 额外信息
    printf "\n📝 说明：\n"
    printf "• 手机总容量：厂商标称值\n"
    printf "• 读取总容量：所有物理分区统计值\n"
    printf "• 差异：%.1f GB (进制换算+预留空间)\n", total_nominal - read_total_gb
}'