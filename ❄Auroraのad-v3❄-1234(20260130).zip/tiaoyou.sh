    

set_perm_recursive $MODPATH 0 0 0755 0644

sdk_version=$(getprop ro.build.version.sdk)
kernel_version=$(uname -r | cut -d'-' -f1) # 6.6.30
compare_versions() {
  if [[ $1 == $2 ]]; then
    echo 0
    return
  fi
  awk -v a="$1" -v b="$2" 'BEGIN {
    split(a, va, "."); split(b, vb, ".");
    for (i = 1; i <= 3; i++) {
      if (va[i] > vb[i]) exit 2;
      if (va[i] < vb[i]) exit 1;
    }
    exit 0;
  }'
  case $? in
    0) echo 0 ;;  # 相等
    1) echo 1 ;;  # b 大于 a
    2) echo -1 ;; # b 小于 a
  esac
}

# 判断拓展内存是否已开启
get_ext_enabled(){
  ext_size=0
  blk=/sys/block/zram0/backing_dev
  # xiaomi linux
  if [[ -f /sys/block/zram0/writeback ]] && [[ -f $blk ]]; then
    blk=$(cat $blk)
    if [[ $blk = *"loop"* ]]; then
      loop_dev=${blk##*/}
      backing_file=$(cat /sys/block/$loop_dev/loop/backing_file)
      ext_size=$(du -b $backing_file | cut -f1)
      # 单位统一为KB
      ext_size=$((ext_size / 1024))
    fi
  else
    # meizu oppo
    for file in smartswap_meminfo hybridswap_meminfo; do
      if [[ -f /sys/block/zram0/$file ]]; then
        ext_size=$(head -1 /sys/block/zram0/$file | tr -s ' ' | cut -d' ' -f2)
      fi
    done
  fi
  # 拓展内存不小于1GB
  if [[ $ext_size -gt 1024000 ]]; then
    echo 1
  else
    echo 0
  fi
}


if [[ -f /dev/memcg/memory.force_swapout ]] || [[ -f /dev/memcg/memory.force_reclaim_zram ]]; then
  memcg_zram_reclaim=1
else
  memcg_zram_reclaim=0
fi

origin_file="/system/vendor/etc/perf/perfconfigstore.xml"
overlay_file="$MODPATH$origin_file"

swap_config="$MODPATH/admin/系统调优.md"

if [[ -f /sys/fs/cgroup/memory/memory.swappiness ]]; then
  scene_memcg="/sys/fs/cgroup/memory"
elif [[ -f /dev/memcg/memory.swappiness ]]; then
  scene_memcg="/dev/memcg"
fi

# update_overlay ro.lmk.enhance_batch_kill false
update_overlay() {
  local prop="$1"
  local value="$2"
  sed -i "s/Name=\"$prop\"[ ]*Value=\".*\"/Name=\"$prop\" Value=\"$value\"/ig" $overlay_file
}
update_system_prop() {
  local prop="$1"
  local value="$2"
  sed -i "s/^$prop=.*/$prop=$value/" $MODPATH/system.prop
  # cat $MODPATH/system.prop | grep $prop
}

get_prop() {
  cat $swap_config | grep "^$1=" | cut -f2 -d '='
}

# 解析旧版模块创建的配置（读取以便保留部分用户自定义配置）
read_current_config() {
  if [[ -f $swap_config ]]; then
    current_swap_enable=$(get_prop swap)
    current_swap_size=$(get_prop swap_size)
    current_swap_use_loop=$(get_prop swap_use_loop)
    current_zram_enable=$(get_prop zram)
    current_zram_size=$(get_prop zram_size)

    if [[ "$current_zram_enable" != "" ]] && [[ "$current_zram_size" != "" ]]; then
      zram_enable="$current_zram_enable"
      zram_size="$current_zram_size"
    fi
    if [[ "$current_swap_enable" != "" ]] && [[ "$current_swap_size" != "" ]]; then
      swap_enable="$current_swap_enable"
      swap_size="$current_swap_size"
    fi

    ui_print "- ZRAM(Customized): ${zram_size}MB"
    if [[ "$swap_enable" == 'true' ]]; then
      ui_print "- SWAP(Customized): ${swap_size}MB"
    else
      ui_print "- SWAP(customized): OFF"
    fi

    if [[ "$current_swap_use_loop" != "" ]]; then
      swap_use_loop="$current_swap_use_loop"
    fi
  fi
  swap_total=$zram_size
  if [[ $swap_enable == 'true' && $swap_size -gt 0 ]]; then
    swap_total=$((swap_total + swap_size))
  fi
  if [[ $swap_total -gt 8000 ]]; then
    extra_free_kbytes=131072 # 128MB
  elif [[ $swap_total -gt 6000 ]]; then
    extra_free_kbytes=98304 # 96MB
  elif [[ $swap_total -gt 4500 ]]; then
    extra_free_kbytes=65536 # 64MB
  elif [[ $swap_total -gt 2000 ]]; then
    extra_free_kbytes=32768 # 32MB
  fi
}

# 检测UFS健康
ufs_health_check2() {
  bDeviceLifeTimeEstA=$(cat /sys/devices/platform/soc/*ufshc*/health_descriptor/life_time_estimation_a 2>/dev/null)
  if [[ "$bDeviceLifeTimeEstA" == "" ]]; then
    mi_health_desc=/sys/class/mi_memory/mi_memory_device/ufshcd0/dump_health_desc
    if [[ -f $mi_health_desc ]];then
      bDeviceLifeTimeEstA=$(grep bDeviceLifeTimeEstA $mi_health_desc 2>/dev/null | cut -f2 -d '=' | cut -f2 -d ' ')
    else
      bDeviceLifeTimeEstA=$(grep bDeviceLifeTimeEstA /sys/kernel/debug/*.ufshc/dump_health_desc 2>/dev/null | cut -f2 -d '=' | cut -f2 -d ' ')
    fi

    if [[ "$bDeviceLifeTimeEstA" == "" ]]; then
      dump_files=$(find /sys -name "dump_*_desc" | grep ufshc)
      for line in $dump_files
      do
        str=$(grep 'bDeviceLifeTimeEstA' $line | cut -f2 -d '=' | cut -f2 -d ' ')
        if [[ "$str" != "" ]]; then
          bDeviceLifeTimeEstA="$str"
        fi
      done
    fi

    if [[ "$bDeviceLifeTimeEstA" == "" ]];then
      files=$(find /sys -name "life_time_estimation_a" | grep ufshc)
      for line in $files
      do
        str=$(cat $line)
        if [[ "$str" != "" ]]; then
          bDeviceLifeTimeEstA="$str"
        fi
      done
    fi
  fi

  case "$bDeviceLifeTimeEstA" in
    "0x01"|"0x1")
      echo 1
    ;;
    *)
      echo 0
    ;;
  esac
}

ufs_version(){
  mi_ufs=$(grep ufs_version /sys/class/mi_memory/mi_memory_device/ufshcd0/show_hba 2>/dev/null| awk '{print $3}')
  if [[ "$mi_ufs" != "" ]]; then
    # 如 0x300 -> 3.0 和 0x400 -> 4.0
    echo ${mi_ufs:2:1}.0
  else
    # 根据特性支持情况判断ufs协议版本，准确率一般
    ufs_features_qcom='/sys/devices/platform/soc/*.ufshc*/device_descriptor/ufs_features'
    ufs_features_mtk='/sys/devices/platform/*ufshc*/device_descriptor/ufs_features'
    ufs_features=$(cat $ufs_features_qcom 2>/dev/null || cat $ufs_features_mtk 2>/dev/null)

    if [[ "$ufs_features" == "0x33" ]]; then
      echo '4.0'
    elif [[ "$ufs_features" == "0x83" ]]; then
      echo '3.1'
    elif [[ "$ufs_features" == "0x81" ]]; then
      echo '3.0'
    fi
  fi
}

get_soc_max_freq(){
  max_freq=0
  for c in /sys/devices/system/cpu/cpufreq/policy*;do
    freq=$(cat $c/cpuinfo_max_freq)
    if [[ $freq -gt $max_freq ]]; then
      max_freq=$freq
    fi
  done
  echo $max_freq
}
hp_soc() {
  # 8en2:341 8+:431 D8100:431 D1000:44 765G:611 730G:62
  clusters=''
  for policy in /sys/devices/system/cpu/cpufreq/policy*
  do
    clusters=${clusters}$(cat $policy/related_cpus | awk '{print NF}')
  done

  if [[ "$clusters" == "431" ]] || [[ "$clusters" == "341" ]] || [[ "$clusters" == "2321" ]] || [[ $(get_soc_max_freq) -gt 3000000 ]]; then
    echo 1
  else
    echo 0
  fi
}

# 检测swappiness支持的最大值
get_swappiness_max() {
  current_swappiness=$(cat /proc/sys/vm/swappiness)
  if [[ $current_swappiness -gt 150 ]]; then
    echo 200
    return
  fi
  echo 100 > /proc/sys/vm/swappiness
  echo 150 > /proc/sys/vm/swappiness
  echo 200 > /proc/sys/vm/swappiness
  swappiness_max=$(cat /proc/sys/vm/swappiness)
  echo $current_swappiness > /proc/sys/vm/swappiness
  echo $swappiness_max
}

# 根据设备性能自动调整参数
auto_config () {
  MemTotalStr=`cat /proc/meminfo | grep MemTotal`
  MemTotalKB=${MemTotalStr:16:8}
  MemTotalGB=$(((MemTotalKB/1024+2047)/2048*2))
  ui_print "- RAM Total:${MemTotalKB}KB (${MemTotalGB} GB?)"

  soc_platform=$(getprop ro.board.platform)

  if [[ $(compare_versions "$kernel_version" "6.6") -lt 0 ]]; then
    swappiness=125
  elif [[ $(get_swappiness_max) -gt 100 ]]; then
    swappiness=150
  fi

  # 优先zstd 如果支持
  if [[ "$(grep lz4k /sys/block/zram0/comp_algorithm)" != '' ]]; then
    algorithm=lz4k
  elif [[ "$(grep lz4 /sys/block/zram0/comp_algorithm)" != '' ]]; then
    algorithm=lz4
  fi

  ext_enabled=$(get_ext_enabled)
  # 如果已开启拓展内存，直接1:1
  if [[ $ext_enabled == '1' ]]; then
    ui_print "- Extend MEM: Supported"
    zram_size=$((MemTotalGB * 1024))
  # 支持zstd算法，设为RAM的70%
  elif [[ "$algorithm" == lz4* ]]; then
    zram_size=$((MemTotalGB * 1024 * 2 / 3))
  # 啥也不支持，ZRAM大小默认为RAM的1/2，相对保守
  else
    zram_size=$((MemTotalGB * 1024))
  fi

  swap_size=$((MemTotalGB * 1024 - zram_size))
  swap_size_limit=$((MemTotalGB * 1024 / 3))
  if [[ $swap_size -gt $swap_size_limit ]]; then
    swap_size=$swap_size_limit
  fi

# 移除高性能SoC和UFS健康检查，默认开启SWAP
swap_enable=false

# ColorOS(OnePlus12)
chp=/sys/block/zram0/hybridswap_loop_device
if [[ -f $chp ]] && [[ $(cat $chp) == 'chp' ]] && [[ -d /sys/block/zram1 ]]; then
    zram_size=0
    zram1_size=$(cat /sys/block/zram1/disksize)
    zram1_size=$((zram1_size/1024/1024))
    swap_size=$((MemTotalGB * 1024 - zram1_size))
    swap_size_limit=$((MemTotalGB * 1024 / 2))
# ZRAM容量足够 关闭swapfile
elif [[ "$zram_size" -gt 9999 ]]; then
    swap_enable=false
fi
  ui_print "- ZRAM(Recommended): ${zram_size}MB"
  if [[ "$swap_enable" == 'true' ]]; then
    ui_print "- SWAP(Recommended): ${swap_size}MB"
  else
    ui_print "- SWAP(Recommended): OFF"
  fi
}

swappiness=100
swappiness_max=100
swap_enable=false
swap_size=2047
swap_use_loop=false
zram_enable=true
zram_size=2047
algorithm=lz4
extra_free_kbytes=25600
swap_priority=-2
# 骁龙865机型后台应用oom_score_adj很容易变高超过900，导致很快被杀死
if [[ $(getprop ro.board.platform) == "kona" ]]; then
  kona_device=1
else
  kona_device=0
fi


# 自动配置
auto_config
# 读取已经存在的配置
read_current_config

if [[ -f '/sys/block/zram0/backing_dev' ]] || [[ -f '/sys/block/zram0/hybridswap_loop_device' ]]; then
zram_writeback_config="
# ZRAM Writeback
# default 保持系统默认配置
# true 开启ZRAM Writeback，并由模块配置回写设备
# false 关闭ZRAM Writeback
zram_writeback=default

"
else
zram_writeback_config=''
fi

  echo "
  
# 是否配置swapfile
swap=$swap_enable

# swapfile大小(MB)，部分设备超过2047会开启失败
# 注意，修改swap大小，需要手动删除/data/swapfile，才会重新创建
swap_size=$swap_size

# swapfile使用顺序
#  0 与zram同时使用
# -2 用完zram后再使用
#  5 优先于zram使用）
swap_priority=$swap_priority

# 是否将swapfile挂载为回环设备
# 在很多设备上性能表现很差。如非必要，不建议开启
swap_use_loop=$swap_use_loop

# 是否配置zram
# 注意: 设为false并不代表禁用zram，而是保持系统默认配置
# 如果你想关闭系统默认开启的zram，则应设为true，并配置zram_size为0
zram=$zram_enable

# zram大小(MB)，部分设备超过2047会开启失败
zram_size=$zram_size

# zram压缩算法(可设置的值取决于内核支持)
# zstd lz4 lzo lzo-rle性能都很好
comp_algorithm=$algorithm

$zram_writeback_config
# 使用SWAP的积极性，0 ~ $swappiness_max
swappiness=$swappiness

# 额外空余内存(kbytes)
# 数值越大越容易触发swap和内存回收
extra_free_kbytes=$extra_free_kbytes

# 水位线调整(1到1000，越大内存回收越积极)
# 例如设为1000，则表示10%，表示内存水位线low-min-high之间，各相差RamSize * 10%
# 剩余内存低于low的值开始回收内存，直到内存不低于high的值。如果我有8G物理内存，那么回收10%就是一口气回收了大概800M，这个过程需要消耗不少性能，导致短时间卡住
# 但是设置太小也会导致swap因为每次回收的内存量太少而效率过低，出现连续的卡顿掉帧
# 因此，请酌情设置watermark_scale_factor
watermark_scale_factor=25

# 设置kswapd进程cpu亲和
# 00001111，表示使用CPU4~7
# kswapd_cpus=00001111

" > $swap_config

device=$(getprop ro.product.vendor.name)
manufacturer=$(getprop ro.product.vendor.manufacturer)
platform=$(getprop ro.board.platform)
soc=$(getprop ro.soc.model | tr 'a-z' 'A-Z')

# Xiaomi'8GEN1
if [[ "$soc" == "SM8450" ]] && [[ "$manufacturer" == "Xiaomi" ]] && [[ $(getprop ro.miui.ui.version.name) != '' ]]; then
  echo '- [Xiaomi] 8GEN1'
  update_system_prop ro.lmk.use_minfree_levels false
  update_system_prop ro.lmk.use_psi true
  update_system_prop ro.lmk.medium 1001
  update_system_prop ro.lmk.critical 900

# MTK 新系统(Android 10+)用PSI，效果更好
elif [[ "$sdk_version" -gt 28 ]] && [[ $(echo "$platform" | grep -e '^mt') != '' ]]; then
  echo '- [Mediatek] Use PSI'
  update_system_prop ro.lmk.use_minfree_levels false
  update_system_prop ro.lmk.use_psi true

# 非MTK 新系统(Android 11+)用PSI，效果更好
elif [[ "$sdk_version" -gt 29 ]]; then
  echo '- [Android 11+] Use PSI'
  update_system_prop ro.lmk.use_minfree_levels false
  update_system_prop ro.lmk.use_psi true

# 喜欢杀后台的特殊机型，特殊对待
elif [[ "$kona_device" == "1" ]]; then
  echo '- [Qualcomm] KONA Use LMK'

  update_system_prop ro.lmk.medium 1001
  # 方式1 使用传统LMK
  update_system_prop ro.lmk.use_minfree_levels true
  update_system_prop ro.lmk.use_psi false

  # 方式2 降低PSI报告积极性
  # update_system_prop ro.lmk.psi_partial_stall_ms 350
fi

if [[ -f $origin_file && -s $origin_file ]]; then
  echo '- Qualcomm perfconfigstore.xml'
  mkdir -p $(dirname $overlay_file)
  cp $origin_file $overlay_file

  update_overlay ro.vendor.perf.enable.prekill false
  update_overlay ro.lmk.kill_heaviest_task_dup false
  update_overlay ro.lmk.enhance_batch_kill false
  update_overlay ro.lmk.enable_watermark_check true
  update_overlay ro.lmk.enable_preferred_apps false

  # 喜欢杀后台的特殊机型，特殊对待
  if [[ "$kona_device" == "1" ]]; then
    update_overlay ro.lmk.super_critical 900
  else
    update_overlay ro.lmk.super_critical 800
  fi
  update_overlay ro.lmk.direct_reclaim_pressure 0
  update_overlay ro.lmk.reclaim_scan_threshold 0

  update_overlay ro.vendor.qti.sys.fw.bg_apps_limit 255

  update_overlay vendor.debug.enable.memperfd false
  update_overlay vendor.appcompact.enable_app_compact false

  update_overlay ro.lmk.nstrat_low_swap 1
  update_overlay ro.lmk.nstrat_psi_partial_ms 250 # default 70
  update_overlay ro.lmk.nstrat_psi_complete_ms 700 # default 70
  update_overlay ro.lmk.psi_scrit_complete_stall_ms 800 # default 400
  update_overlay ro.lmk.nstrat_psi_scrit_complete_stall_ms 800

  update_overlay vendor.prekill_MIN_ADJ_to_Kill 906 # default 800
  update_overlay vendor.prekill_MAX_ADJ_to_Kill 1001 # default 1000
  update_overlay vendor.enable.memperfd_MIN_RAM_in_KB 393216 # default 1048576 
  update_overlay vendor.enable.memperfd_MAX_RAM_in_KB 15728640 # default 15728640
  update_overlay ro.lmk.cache_percent 5 # default 10
  
fi

ui_print " "
ui_print "完成 "

